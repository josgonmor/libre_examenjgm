package com.josgonmor.examenjosegm.data

data class Producto (val nombre: String, val precio: Int)